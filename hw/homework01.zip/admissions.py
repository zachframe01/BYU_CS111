# Provided code
# This function checks to ensure that a list is of length
# 8 and that each element is type float
# Parameters:
# row - a list to check
# Returns True if the length of row is 8 and all elements are floats
def check_row_types(row):
    if len(row) != 8:
        print("Length incorrect! (should be 8): " + str(row))
        return False
    ind = 0
    while ind < len(row):
        if type(row[ind]) != float:
            print("Type of element incorrect: " + str(row[ind]) + " which is " + str(type(row[ind])))
            return False
        ind += 1
    return True
	
# define your functions here


def main():
    filename = "admission_algorithms_dataset.csv"
    input_file = open(filename, "r")    
    
    
    print("Processing " + filename + "...")
    # grab the line with the headers
    headers = input_file.readline()
    
    # TODO: loop through the rest of the file



    # TODO: make sure to close all files you've opened!

    print("done!")

# this bit allows us to both run the file as a program or load it as a
# module to just access the functions
if __name__ == "__main__":
    main()
