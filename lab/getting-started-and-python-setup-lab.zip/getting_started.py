def eighteen_seventy_five():
    """Come up with the most creative expression that evaluates to 1875,
    using only numbers and the +, *, and - operators.

    >>> eighteen_seventy_five()
    1875
    """
    return 1874
