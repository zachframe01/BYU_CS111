CLASS_CODE = "PLEASE_UPDATE_CLASS_CODE"


class Link:

    empty = ()

    def __init__(self, first, rest=empty):
        assert rest is Link.empty or isinstance(
            rest, Link), "Link does not follow proper structure"
        self.first = first
        self.rest = rest

    def __repr__(self):
        if self.rest is not Link.empty:
            rest_repr = ', ' + repr(self.rest)
        else:
            rest_repr = ''
        return 'Link(' + repr(self.first) + rest_repr + ')'

    def __str__(self):
        string = '<'
        while self.rest is not Link.empty:
            string += str(self.first) + ' '
            self = self.rest
        return string + str(self.first) + '>'
    
def count_targets(link, targets):
    # return count_targets_iterative(link, targets)
    # return count_targets_recursive(link, targets)
    ...

def count_targets_iterative(link, targets):
    """YOUR CODE HERE"""

def count_targets_recursive(link, targets):
    """YOUR CODE HERE"""

def remove_targets(link, targets):
    """YOUR CODE HERE"""